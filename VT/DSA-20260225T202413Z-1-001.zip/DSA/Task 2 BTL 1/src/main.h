#ifndef __MAIN_H__
#define __MAIN_H__

#include <iostream>
#include <sstream>
#include <string>
#include <stdexcept>
#include <cmath>
#include "utils.h"

using namespace std;

#endif // __MAIN_H__